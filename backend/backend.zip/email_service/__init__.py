# Initialize the email_service app
default_app_config = 'email_service.apps.EmailServiceConfig'
